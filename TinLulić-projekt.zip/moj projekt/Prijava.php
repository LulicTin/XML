<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Početna stranica</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" type="text/css" href="TinLulić-početna.css" >
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ropa+Sans&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kdam+Thmor+Pro&display=swap" rel="stylesheet">
</head>
<body class="body1">
    <nav id="navigacija">
        <ul>
            <li><a id="prviLink" href="TinLulić-početna.html">POČETNA</a></li>
            <li><a href="TinLulić-ponuda.html">PONUDA</a></li>
            <li><a href="TinLulić-kontakt.html">KONTAKT</a></li>
            <li><a href="Prijava.php">PRIJAVA</a></li>
        </ul>
    </nav>
    <br><br><hr><br><br>
    <form action="" method="post" class="forma">
        Korisnički račun: <input type="text" id="name" name="username"><br>
        Lozinka: <input type="password" id="password" name="password" placeholder="*******"><br>
        <input type="submit" name="submit" value="login">
    </form>
    <?php
    $username="";
    $password="";
       function provjera($username, $password) {

        $xml = simplexml_load_file("Korisnici.xml");
    
        foreach ($xml -> Korisnik as $usr) {
            $usrn = $usr -> username;
            $usrp = $usr -> password;
            $usrime = $usr -> ime;
            $usrprezime = $usr -> prezime;
    
            if ($usrn == $username){
                if ($usrp == $password){
                    echo "Prijavljeni ste kao $usrime $usrprezime";
                    return;
                }
            else{
                echo "Netočna lozinka";
                return;
                }
            }
        }
    
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $ans = $_POST;
        
            if (empty($ans["username"])) {
                echo "Korisnički račun nije unesen.";
            }
            elseif (empty($ans["password"])) {
                echo "Lozinka nije unesena.";
            }
            else {
                $username = $ans["username"];
                $password = $ans["password"];
        
                provjera($username, $password);
            }
        }

        echo "Korisnik ne postoji.";
        return;
    } 
    ?>
    <br><br>
    <footer>
        &copy; TIN LULIć - 2022.
    </footer>
</body>
</html>